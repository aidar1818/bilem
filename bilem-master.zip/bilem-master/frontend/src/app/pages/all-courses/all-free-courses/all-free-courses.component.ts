import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { Course } from "../../../models/course.model";
import { Store } from "@ngrx/store";
import { AppState } from "../../../store/types";
import { fetchCoursesRequest } from "../../../store/course/course.actions";

@Component({
  selector: 'app-all-free-courses',
  templateUrl: './all-free-courses.component.html',
  styleUrls: ['./all-free-courses.component.css']
})
export class AllFreeCoursesComponent implements OnInit {
  courses: Observable<Course[] | null>;
  loading: Observable<boolean | null>;

  constructor(private store: Store<AppState>) {
    this.courses = store.select(state => state.courses.courses);
    this.loading = store.select(state => state.courses.fetchLoading);
  }

  ngOnInit(): void {
    this.store.dispatch(fetchCoursesRequest());
  }
}
