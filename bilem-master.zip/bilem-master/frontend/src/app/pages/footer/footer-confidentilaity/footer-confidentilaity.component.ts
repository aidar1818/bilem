import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-confidentilaity',
  templateUrl: './footer-confidentilaity.component.html',
  styleUrls: ['./footer-confidentilaity.component.css']
})
export class FooterConfidentilaityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
