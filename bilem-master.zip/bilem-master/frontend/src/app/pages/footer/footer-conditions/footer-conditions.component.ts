import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-conditions',
  templateUrl: './footer-conditions.component.html',
  styleUrls: ['./footer-conditions.component.css']
})
export class FooterConditionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
