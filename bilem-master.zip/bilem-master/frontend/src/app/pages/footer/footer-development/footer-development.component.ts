import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-development',
  templateUrl: './footer-development.component.html',
  styleUrls: ['./footer-development.component.css']
})
export class FooterDevelopmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
