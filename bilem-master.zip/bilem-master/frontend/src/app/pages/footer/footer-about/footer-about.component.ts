import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-about',
  templateUrl: './footer-about.component.html',
  styleUrls: ['./footer-about.component.css']
})
export class FooterAboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
