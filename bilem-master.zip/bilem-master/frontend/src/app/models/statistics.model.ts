export class Statistics {
  constructor(
    public courses: number,
    public students: number,
    public lessons: number,
    public comments: number,
  ) {}
}
