export const environment = {
  production: true,
  apiUrl: 'https://bilem-online.ddnsfree.com/api',
  fbAppId: '407104017926294',
  googleAppId: '324167406660-o6ge0kgc0d1vknbjsb1366ao5np0vdns.apps.googleusercontent.com'
};
