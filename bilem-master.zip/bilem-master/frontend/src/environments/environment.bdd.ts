export const environment = {
  production: false,
  apiUrl: 'http://localhost:8010',
  fbAppId: '407104017926294',
  googleAppId: '324167406660-o6ge0kgc0d1vknbjsb1366ao5np0vdns.apps.googleusercontent.com'
};
